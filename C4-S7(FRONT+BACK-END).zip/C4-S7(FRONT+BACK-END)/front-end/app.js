const app = Vue.createApp({
  data() {
    return {
      api_base: "http://127.0.0.1:8000/api/todos",
      inputTtitle: "",
      inputContent: "",
      listOfTasks: [],
      isInputEmpty: false,
      selecteOption: 'all',
    };
  },
  methods: {
    addTask(){
      if ((this.inputTtitle.trim() && this.inputContent.trim()) != ""){
        axios.post(this.api_base,{'title': this.inputTtitle, 'content': this.inputContent})
        .then((response)=>{
          this.displayTask();
        });
        this.inputTtitle = "";
        this.inputContent = "";
        this.isInputEmpty = false;
      }else{
        this.isInputEmpty = true;
      }
    },
    displayTask(){
      axios.get(this.api_base).then((result)=>{
        this.listOfTasks = result.data;
      })
    },
    deleteTask(id){
      axios.delete(this.api_base+"/"+id).then((response)=>{
        this.displayTask();
      });
    },
    markAsImportant(id){
      axios.put(this.api_base + "/" + id).then((response)=>{
        this.displayTask();
      });
    },
  },
  computed: {
    showListOfTask(){
      if(this.selecteOption == "important-only"){
        return this.listOfTasks.filter(task=>task.status);
      } else if (this.selecteOption == 'not-important'){
        return this.listOfTasks.filter(task=> !task.status);
      }
      return this.listOfTasks;
    },
  },
  mounted() {
    this.displayTask();
  }
});

app.mount("#app");
