<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <script src="https://unpkg.com/vue@next" ></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="../js/app.js" defer></script>
    <link rel="stylesheet" href="../css/app.css">
  </head>

  <body>
    <div id="app"  v-cloak>
      <div class="container">
        <h2>Create a todo item</h2>
        <form  @submit.prevent="addTask">
              <input type="text" placeholder="Title" v-model="inputTtitle"/>
              <input type="text" placeholder="Content" v-model="inputContent"/>
              <button class="btn btn-primary" type="submit">Create</button>
        </form>
        <div class="alert alert-danger" v-if="isInputEmpty">Please fill all requirement</div>
        <main>
          <div class="main-title">
            <h2>My todo list</h2>
            <select v-model="selecteOption"> 
              <option value="all" selected>Show all</option>
              <option value="important-only">Show only important</option>
              <option value="not-important">Show only not important</option>
            </select>
          </div>
          <div class="main-card" v-if="showListOfTask.length">
            <div class="card" v-for="task in showListOfTask" :id="task.id" :class="[task.status?'important':'not_important']">
              <h3><?php echo e(task.title); ?></h3>
              <p><?php echo e(task.content); ?></p>
              <div class="group-btn">
                <button class="btn btn-danger mx-2" @click="deleteTask(task.id)">Delete</button>
                <button class="btn btn-light" @click="markAsImportant(task.id)" v-if="task.status">Mark not important</button>
                <button class="btn  btn-warning" @click="markAsImportant(task.id)" v-else>Mark as Important</button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  </body>
</html>
<?php /**PATH C:\Users\sauth.phouek\Desktop\1 - START CODE\back-end\resources\views/index.blade.php ENDPATH**/ ?>